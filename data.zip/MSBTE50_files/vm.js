

function new_window(theURL,winName,features)
{ 
window.open(theURL,winName,features);
}

function OpenWindow(theURL,winName,features) {
  window.open(theURL,winName,features);
}


function numbersonly(e) {
var key;
var keychar;

if (window.event) {
   key = window.event.keyCode;
}
else if (e) {
   key = e.which;
}
else {
   return true;
}
keychar = String.fromCharCode(key);

if ((key==null) || (key==0) || (key==8) ||  (key==9) || (key==13) || (key==27) ) {
   return true;
}
else if ((("0123456789").indexOf(keychar) > -1)) {
   return true;
}
else if ( ( !(/\./g.test(getTarget(e).value)) ) && (keychar == ".") ) { 
  return true;
}
else
	alert ('Not Allowed Characters....');
	return false;
}




function validate_form_add_fac() 
{
	var name = document.frm.name2.value;
	var desig = document.frm.desig.value;
	var keychar;
	if( name=='' )
	{
		alert ('Enter Name of Faculty....');
		return false;
	}
	if( desig=='' )
	{
		alert ('Enter Designation of Faculty....');
		return false;
	}
}




function validate_form_stud_att() 
{
	var sr_no = document.frm.sr_no.value;
	var std_name = document.frm.std_name.value;
	var sub = document.frm.sub.value;
	var att_day = document.frm.att_day.value;
	var date = document.frm.date.value;
	var keychar;
	if( sr_no=='' )
	{
		alert ('Enter Sr. No. of Student....');
		return false;
	}
	if( std_name=='' )
	{
		alert ('Enter Student Name....');
		return false;
	}
	if( sub=='' )
	{
		alert ('Enter Subject Name....');
		return false;
	}
	if( att_day=='' )
	{
		alert ('Enter Attendance Day....');
		return false;
	}
	if( date=='' )
	{
		alert ('Enter Date....');
		return false;
	}
}