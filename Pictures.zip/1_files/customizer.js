/* global wp, jQuery */
/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */
(function ($) {
	if ($('iframe[name=give-embed-form]').length) {
		$('iframe[name=give-embed-form]').on('load', function () {
			var iBody = $("iframe[name=give-embed-form]").contents().find("body");
			var purchaseBtn = iBody.find("#give-purchase-button");
			purchaseBtn.on('click', function () {
				$('html, body').animate({
					scrollTop: $(".give-embed-form-wrapper").offset().top
				}, 2000);
			});
		});
	}
	jQuery( document ).ready(function() {
		if (jQuery(".timeline").length) {
			jQuery().timelinr({
				arrowKeys: 'false',
				autoPlay: 'true',
				issuesSpeed: 'slow',
				issuesTransparency: 1,
				autoPlayPause: 5000
			});
		}
	});
	jQuery('#play-video').on('click', function (e) {
		e.preventDefault();
		var video_id = jQuery(this).attr('href');
		jQuery('#video-overlay').addClass('open');
		jQuery("#video-overlay").append('<iframe width="860" height="600" src="https://www.youtube.com/embed/' + video_id + '" frameborder="0" allowfullscreen></iframe>');
	});

	jQuery('.video-overlay, .video-overlay-close').on('click', function (e) {
		e.preventDefault();
		close_video();
	});

	jQuery(document).keyup(function (e) {
		if (e.keyCode === 27) { close_video(); }
	});

	function close_video() {
		jQuery('.video-overlay.open').removeClass('open').find('iframe').remove();
	};

	jQuery(".hamburger-menu").on('click', function () {
		jQuery(".overlay").fadeToggle(200);
	});

	jQuery(".burger-squeeze").on('click', function () {
		jQuery(".overlay").fadeToggle(200);
	});
	if (jQuery(".single-donation").length) {
		jQuery(".single-donation").click(function () {
			window.location = $(this).find("a").attr("href");
			return false;
		});
	}
	if (jQuery(".monthly-donation").length) {
		jQuery(".monthly-donation").click(function () {
			window.location = $(this).find("a").attr("href");
			return false;
		});
	}
	if (jQuery('.banner-slider-section').length) {
		var numitems = jQuery('.banner-slider').children('figure.bg-cover').length;
		if (numitems == 1) {
			jQuery(".banner-slider-section .navigation").hide();
		}
	}
	jQuery("ul.max-mega-menu").on("after_mega_menu_init", function () {
		var idArr = [];
		jQuery("li.mega-menu-item:not(.mega-toggle-on)").add('span.mega-indicator').on('click', function (e) {
			if (idArr.length > 0) {
				$(`#${idArr[0]}`).removeClass("mega-toggle-on");
				idArr.shift();
			}

			idArr.push(jQuery("li.mega-toggle-on").attr("id"));
			console.log(idArr)

		});

	});


	var urlParams = new URLSearchParams(window.location.search);
	if (urlParams.has("donate-type") || urlParams.has("donate-name")) {
		currentUrl = window.location.origin;
		if (urlParams.get("donate-type") === "monthly") {
			jQuery("iframe").on("load", function () {
				var iFrameDOM = jQuery("iframe[name=give-embed-form]").contents();
				iFrameDOM.find(".give-recurring-donors-choice").addClass("active");
				iFrameDOM.find('input[type="checkbox"]').attr("checked", true);
			});
		}
		if (urlParams.has("donate-name")) {
			var donate_name = decodeURI(urlParams.get("donate-name"));
			jQuery("iframe").on("load", function () {
				var iFrameDOM = jQuery("iframe[name=give-embed-form]").contents();
				iFrameDOM.find("select#ffm-fund").find('option[value="' + donate_name + '"]').attr("selected", true);
			});
		}
	}

	jQuery('.close-btn-overlay').on('click', function () {
		jQuery(".overlay").fadeToggle(200);
	});

	if (jQuery('.banner-slider').length) {
		jQuery('.banner-slider').slick({
			dots: true,
			infinite: true,
			speed: 500,
			autoplay: true,
			mobileFirst:true,
			centerMode: true,
			autoplaySpeed: 7000,
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: true,
			fade: true,
			cssEase: 'linear',
			appendDots: jQuery('.appendDots'),
			prevArrow: jQuery('.prev-slide'),
			nextArrow: jQuery('.next-slide')
		}).on('setPosition', function (event, slick) {
			slick.$slides.css('height', slick.$slideTrack.height() + 'px');
		});
		jQuery('.pause').on('click', function () {
			jQuery('.banner-slider')
				.slick('slickPause')
				.slick('slickSetOption', 'pauseOnDotsHover', false);
		});

		jQuery('.play').on('click', function () {
			jQuery('.banner-slider')
				.slick('slickPlay')
				.slick('slickSetOption', 'pauseOnDotsHover', true);
		});
		jQuery('.banner-slider').slick('slickPlay');
	}


	if (jQuery('.post-slider').length) {
		jQuery('.post-slider').slick({
			infinite: true,
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: false,
			speed: 800,
			autoplay: true,
			autoplaySpeed: 7000,
			nextArrow: jQuery('.next-post'),
			adaptiveHeight: true
		});
	}

	$(window).on("scroll", function () {
		$(window).scrollTop() >= 50 ? $(".sticky-header").addClass("stickyadd") : $(".sticky-header").removeClass("stickyadd");
	});

	$('input[name="give-purchase"]').on('click', function () {
		$(window).scrollTop();
	});

	//highlight sidebar menu in current page
	var id = get_current_page_id();
	if (jQuery(".sidebar-sticky").length) {
		if (jQuery("ul.sub-menu > li.page-item-" + `${id}`).length) {
			jQuery("ul.sub-menu > li.current_page_item").addClass("active-menu-item-sidebar");
		}
	}
	// smooth anchor display
	var $root = $('html, body');
	var $offset = 400 ;

	$('a[href^="#"]').click(function (e) {
		e.preventDefault();
		$root.animate({
			scrollTop: $( $.attr(this, 'href') ).offset().top - $offset 
		}, 1000);
	
		return false;
	});

	// check hr tag
	if ($(".three-col-post-tag")[0]){
		$('#hori-subscribe').hide();

	}

	if( $('.fullwidth-content-area .wp-block-cover').css('background-image') !== 'none' ){
		$('#hori-subscribe').hide();
	}
	
	
	if(jQuery("iframe[name=give-embed-form]").length){
		jQuery("iframe").on("load", function () {
			var attr = $(this).attr('data-contentloaded');
				if(jQuery("iframe[name=give-embed-form]").attr('data-contentloaded') !== undefined) {
					console.log('The name attribute exists');
				}
				else {
					$(this).attr('data-contentloaded',1);
				}	
		});
	}
	


}(jQuery));

function get_current_page_id() {
	var page_body = $('body.page');

	var id = 0;

	if (page_body) {
		var classList = page_body.attr('class').split(/\s+/);

		$.each(classList, function (index, item) {
			if (item.indexOf('page-id') >= 0) {
				var item_arr = item.split('-');
				id = item_arr[item_arr.length - 1];
				return false;
			}
		});
	}
	return id;
}