jQuery(document).ready(function($) {
  $('iframe[name=give-embed-form]').ready(function() {
    //console.log('iframe has loaded', $('iframe[name=give-embed-form]').attr('src'));
    if ($('iframe[name=give-embed-form]').css('visibility') == 'visible') {
      //console.log('iframe is visible');
    } else {
      //console.log('iframe is not visible, fixing..');
      //Hide the iframe loader
      $('.iframe-loader').hide();
      //Set the iframe visibility
      $('iframe[name=give-embed-form]').css("visibility", "visible");
      //Set no scrolling attr
      $('iframe[name=give-embed-form]').attr("scrolling", "no");
    }
  });
});
