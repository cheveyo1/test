jQuery(document).ready(function ($) {
    var cat = 0;
    //var pageNumber = 1;
    $('form#piw_filters').submit(function (e) {
        return false;
    });

    function load_posts(postType, postCat, postTax, searchTerm, keyword, ppp, nextPage) {
        var pageNumber = nextPage;
        /*var str = ''&pageNumber=' + pageNumber + '&ppp=' + ppp + '&action=more_post_ajax';*/
        var str = '&pageNumber=' + pageNumber + '&ppp=' + ppp + '&pt=' + postType + '&ptax=' + postTax + '&pc=' + postCat + '&sTerm=' + searchTerm + '&keyword=' + keyword + '&action=more_post_ajax';
        $.ajax({
            type: "POST",
            dataType: "html",
            url: ajax_posts.ajaxurl,
            data: str,
            success: function (data) {
                var $data = $(data);

                if ($data.length) {

                    if (postType == "events" && !postCat) {
                        $("#archive-content-wrap").append($data);
                        var element = $("#archive-content-wrap");
                    } else if (postType == "post" && !postCat) {
                        $('#current-article-count').text(pageNumber);
                        $("#archive-content-wrap").append($data);
                        var element = $("#archive-content-wrap");
                    } else if (postType == "post" && postCat) {
                        $("#tax-content-wrap").append($data);
                        var element = $("#tax-content-wrap");
                    } else if (postType == "publications" && postCat) {
                        $("#tax-content-wrap").append($data);
                        var element = $("#tax-content-wrap");
                    } else if (postType == "any") {
                        $("#search-content-wrap").append($data);
                    } else {
                        $("#archive-content-wrap").append($data);
                        var element = $("#piw-news-wrap");
                    }
                    $("#more_posts").attr("disabled", false);
                } else {
                    $("#more_posts").attr("disabled", true);
                }
                if ($(element).find('div.last-post').length) {
                    $(element).find('div.last-post').remove();
                    $("#more_posts").hide();
                }
                count_blocks();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $loader.html(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }

        });
        return false;
    }

    function count_blocks() {
        var media_length = $("#archive-content-wrap > div.filter-wrap").length;
        $('#count-status .upt-count').text(media_length);

    }

    function count_post_block() {
        var media_post_length = $(".check-post-count").data('val');
        var media_length = $("#archive-content-wrap > div.filter-wrap").length;
        $('#count-status .upt-count').text(media_length);
        $('#count-status .tot-count').text(media_post_length);

    }

    $("#more_posts").on("click", function (e) { // When btn is pressed.
        e.preventDefault();
        $("#more_posts").attr("disabled", true); // Disable the button, temp.
        var postType = $(this).data('post-type');
        var postCat = $(this).attr('data-cat');
        var postTax = $(this).data('taxonomy');
        var searchTerm = $('.search-header form.search-form input[name="s"]').val();
        var ppp = $(this).data('per-page'); // Post per page
        var keyword = $('#keyword-title').val();
        var currentPage = $(this).attr('data-current-page');
        var nextPage = parseInt(currentPage) + 1;
        load_posts(postType, postCat, postTax, searchTerm, keyword, ppp, nextPage);
        $(this).attr('data-current-page', nextPage);
    });

    function filter_load_posts(postType, postCat, postTax, ppp, pageNumber) {
        /*var str = ''&pageNumber=' + pageNumber + '&ppp=' + ppp + '&action=more_post_ajax';*/
        var str = '&cat=' + cat + '&pageNumber=' + pageNumber + '&ppp=' + ppp + '&pt=' + postType + '&ptax=' + postTax + '&pc=' + postCat + '&action=filter_post_ajax';
        $.ajax({
            type: "POST",
            dataType: "html",
            url: ajax_posts.ajaxurl,
            data: str,
            beforeSend: function () {
                // Show image container
                $("#loader").show();
            },
            success: function (data) {
                var $data = $(data);
                if ($data.length) {
                    if (postType == "events" && !postCat) {
                        $("#archive-content-wrap").html('');
                        $("#archive-content-wrap").append($data);
                        var element = $("#archive-content-wrap");

                    } else if (postType == "post" && !postCat) {
                        $("#archive-content-wrap").html('');
                        $("#archive-content-wrap").append($data);
                        var element = $("#archive-content-wrap");

                    } else if (postType == "post" && postCat) {
                        $("#archive-content-wrap").html('');
                        $("#archive-content-wrap").append($data);
                        var element = $("#archive-content-wrap");

                    } else if (postType == "publications" && postCat) {
                        $("#tax-content-wrap").html('');
                        $("#tax-content-wrap").append($data);
                        var element = $("#tax-content-wrap");

                    } else {
                        $("#piw-news-wrap").html('');
                        $("#piw-news-wrap").append($data);
                        var element = $("#piw-news-wrap");
                    }

                    $("#more_posts").attr("disabled", false);
                } else {
                    $("#more_posts").attr("disabled", true);
                }
                if ($(element).find('div.last-post').length) {
                    $(element).find('div.last-post').remove();
                    $("#more_posts").hide();
                }
                count_post_block();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $loader.html(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }

        });
        return false;
    }

    $('.filter-wrap .cat-title').on('click', function (event) {
        event.preventDefault();
        var postCat = $(this).data('id');
        $("#more_posts").attr('data-current-page', 1);

        var postType = "post";
        var postTax = "category";
        var ppp = $("#more_posts").data('per-page'); // Post per page
        var pageNumber = $("#more_posts").attr('data-current-page');

        filter_load_posts(postType, postCat, postTax, ppp, pageNumber);

    });

    if ($('.single .related-post').css('background-image') !== 'none') {
        console.log("heyyy");
        $('#hori-subscribe').hide();
    }

});


jQuery(window).on('load', function () {

    if (jQuery("body").hasClass("page-template-archive-media-center")) {
            function GetURLParameter() {
                var pageURL = window.location.href;
                var sPageURL = pageURL.substr(pageURL.lastIndexOf('/') + 1);
                var sURLVariables = sPageURL.replace('#', '');

                return sURLVariables;

            }

            var tagtrigger = GetURLParameter();
            if (tagtrigger) {

                var postType = "post";
                var postTax = "category";
                var ppp = $("#more_posts").data('per-page'); // Post per page
                var pageNumber = $("#more_posts").attr('data-current-page');
                var postCat = tagtrigger;
                var str = '&pageNumber=' + pageNumber + '&ppp=' + ppp + '&pt=' + postType + '&ptax=' + postTax + '&pc=' + postCat + '&action=filter_post_ajax';
                jQuery.ajax({
                    type: "POST",
                    dataType: "html",
                    url: ajax_posts.ajaxurl,
                    data: str,
                    beforeSend: function () {
                        // Show image container
                        $("#loader").show();
                    },
                    success: function (data) {
                        $('html, body').animate({
                            scrollTop: $("#list-media").offset().top - 200
                        }, 2000);
                        var $data = $(data);
                        if ($data.length) {
                            if (postType == "events" && !postCat) {
                                $("#archive-content-wrap").html('');
                                $("#archive-content-wrap").append($data);
                                var element = $("#archive-content-wrap");

                            } else if (postType == "post" && !postCat) {
                                $("#archive-content-wrap").html('');
                                $("#archive-content-wrap").append($data);
                                var element = $("#archive-content-wrap");

                            } else if (postType == "post" && postCat) {
                                $("#archive-content-wrap").html('');
                                $("#archive-content-wrap").append($data);
                                var element = $("#archive-content-wrap");

                            } else if (postType == "publications" && postCat) {
                                $("#tax-content-wrap").html('');
                                $("#tax-content-wrap").append($data);
                                var element = $("#tax-content-wrap");

                            } else {
                                $("#piw-news-wrap").html('');
                                $("#piw-news-wrap").append($data);
                                var element = $("#piw-news-wrap");
                            }

                            $("#more_posts").attr("disabled", false);
                        } else {
                            $("#more_posts").attr("disabled", true);
                        }
                        if ($(element).find('div.last-post').length) {
                            $(element).find('div.last-post').remove();
                            $("#more_posts").hide();
                        }
                        //count_post_block
                        var media_post_length = $(".check-post-count").data('val');
                        var media_length = $("#archive-content-wrap > div.filter-wrap").length;
                        $('#count-status .upt-count').text(media_length);
                        $('#count-status .tot-count').text(media_post_length);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        $loader.html(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                    }

                });
                return false;
            };
    }
});