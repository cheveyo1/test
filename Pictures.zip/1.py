import requests
import json
import pymysql
from flask import Flask, request

# 定义数据库连接信息
DB_HOST = "localhost"
DB_PORT = 3306
DB_USER = "root"
DB_PASSWORD = "root"
DB_DATABASE = "test"

# 定义数据库表结构
TABLE_NAME = "data"

# 定义接口函数
def write_data(data):
    # 连接数据库
    print('================')
    print(data)
    conn = pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASSWORD, database=DB_DATABASE)

    # 插入数据
    cur = conn.cursor()
    cur.execute("INSERT INTO {} (tradeId, amount) VALUES (%s, %s, %s)", ( data["tradeId"], data["amount"]))

    # 提交事务
    conn.commit()

    # 关闭连接
    conn.close()

# 启动 HTTP 服务器
app = Flask(__name__)

@app.route("/api/write", methods=["POST"])
def write_data_api():

    # 接收数据
    print(request.data)
    data = json.loads(request.data)


    # 写入数据
    write_data(data)

    # 返回响应
    return json.dumps({"status": "success"})

if __name__ == "__main__":
    app.run(debug=True)